from setuptools import setup, find_packages

setup(name="PyNMA",
      version="1.0",
      description="Python Module for NotifyMyAndroid API",
      url="https://github.com/uskr/pynma",
      packages=find_packages()
      )
